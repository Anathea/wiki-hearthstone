<?php
echo '<!DOCTYPE html>
<html lang="fr">
<head>
	<meta charset="UTF-8">
        <link href="https://fonts.googleapis.com/css?family=Lato" rel="stylesheet">
	<link href="https://fonts.googleapis.com/css?family=Asul" rel="stylesheet">
	<link href="styles/style.css" rel="stylesheet" type="text/css">
	<title>Hearthstone Wiki</title>
</head>
<body>
	<main class="clearfix">

		<a href="cards.php"><div class="logodiv">
                <img class="logo" src="../img-layout/hearthstone_logo.png" alt="Logo Hearthstone">
                </div></a>


    <img class="wallpaper" src="../img-content/hearthstone-wallpaper1.jpg" alt="wallpaper">
</div>
<div class="message">Panneau d\'administration</div>
<section class="liste"><h1>Les cartes Hearthstone</h1>';
