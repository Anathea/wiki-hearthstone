<?php
echo '</section>
</main>
        <footer><a class="ajout" href="ajoutcarte.php">Ajouter une carte</a>
                <a class="footeradmin" href="../cards.php">Version utilisateur</a>
        </footer>
    </body>';
