<?php
echo '</section>
</main>
        <footer><a class="ajout" href="ajoutcarte.php">Ajouter une carte</a>
                <a class="footeradmin" href="admin/cards.php">Version adminisrateur</a>
        </footer>
    </body>';
